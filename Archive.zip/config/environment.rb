# Load the Rails application.
require_relative 'application'
OAUTH_10_SUPPORT = true
# Initialize the Rails application.
Rails.application.initialize!
